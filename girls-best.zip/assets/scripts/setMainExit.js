import {
    makeExit
} from "./shared-FUMZZXRW.js";
import {
    parseConfig
} from "./shared-CMU7KO4O.js";
import "./shared-MVF2V5UU.js";
import "./shared-LB7BSKAZ.js";
var config = parseConfig();
document.addEventListener("click", () => {
    makeExit(config, "mainExit");
});